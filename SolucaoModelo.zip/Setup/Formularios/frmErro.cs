﻿using System.Windows.Forms;

namespace Setup.Formularios
{
    public partial class frmErro : Form
    {
        public frmErro()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, System.EventArgs e)
        {
            this.Dispose();
        }
    }
}
